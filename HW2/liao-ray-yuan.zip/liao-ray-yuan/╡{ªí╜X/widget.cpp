#include "widget.h"
#include <QPainter>
#include <QSlider>
#include <QVBoxLayout>
#include "./ui_widget.h"
#include <QPen>
#include <QColor>
#include <QFileDialog>
#include <QStandardPaths>


Widget::Widget(QWidget *parent)
    : QWidget(parent), drawing(false), ui(new Ui::Widget), drawingRectangle(false), drawingCircle(false),
    currentMode(Pen)
{

    ui->setupUi(this);
    int interfaceWidth = 1000;
    int interfaceHeight = 700;
    this->resize(interfaceWidth, interfaceHeight);
    QString widgetStyle = "QWidget {"
                          "    background-color: #D2B48C;"  // 褐色背景，類似木頭色
                          "}";
    this->setStyleSheet(widgetStyle);


    pixmap = QPixmap(QSize(1000, 500));
    pixmap.fill(Qt::white);
    penColor = Qt::black;
    pen.setColor(penColor);

    lastPoint = QPoint();

    ui->penSizeSlider->setRange(1, 20); // 設定範圍
    ui->penSizeSlider->setValue(3); // 設定初始值
    connect(ui->penSizeSlider, &QSlider::valueChanged, this, &Widget::on_penSizeSlider_actionTriggered);

}

Widget::~Widget()
{
    delete ui;
}

void Widget::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.drawPixmap(0, 0, pixmap);

    QPen currentPen(penColor, lineThickness);
    painter.setPen(currentPen);


    for (int i = 0; i < linePoints.size() - 1; ++i) {
        QPen currentPen(penColor, lineThickness);
        painter.setPen(currentPen);
        painter.drawLine(linePoints[i], linePoints[i + 1]);
    }
}


void Widget::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        linePoints.clear();
        lastPoint = event->pos();
        drawing = true;
        linePoints.append(lastPoint);
        lineColors.append(penColor);
        if (drawingRectangle) {
            // 設置矩形的左上角
            currentRect.setTopLeft(lastPoint);
            currentRect.setBottomRight(lastPoint);
        }
        if (drawingCircle) {
            // 設置圓形的起始點
            circleStartPoint = lastPoint;
        }
    }

}

void Widget::mouseMoveEvent(QMouseEvent *event)
{


    if (drawingRectangle) {
        if (event->buttons() & Qt::LeftButton) {
            // 計算矩形的右下角位置
            currentRect.setBottomRight(event->pos());
            update();
        }
    }
    else if (drawingCircle) {
        if (event->buttons() & Qt::LeftButton) {
            // 计算圆形的位置和半径
            int radius = QLineF(circleStartPoint, event->pos()).length();
            QPointF center = QPointF((circleStartPoint.x() + event->pos().x()) / 2.0,
                                     (circleStartPoint.y() + event->pos().y()) / 2.0);

            currentCircle = QRectF(center.x() - radius, center.y() - radius,
                                   radius * 2, radius * 2);
            update();
        }}
    else if ((event->buttons() & Qt::LeftButton) && drawing) {
        if (currentMode == Pen) {
            QPainter painter(&pixmap);
            painter.setPen(QPen(penColor, lineThickness));
            pen.setCapStyle(Qt::RoundCap);
            painter.drawLine(lastPoint, event->pos());
            lastPoint = event->pos();
            update();
            linePoints.append(lastPoint);
        }
    }
}

void Widget::mouseReleaseEvent(QMouseEvent *event)
{
    if (drawingRectangle) {
        // 完成矩形的繪製，將其添加到畫布上
        //drawingRectangle = false;
        QPainter painter(&pixmap);
        QPen pen(penColor);
        pen.setWidth(lineThickness);
        painter.setPen(pen);
        QRect rect(currentRect.normalized());
        painter.drawRect(rect);
        update();}
    else if (drawingCircle) {
        // 完成圆形的绘制，将其添加到画布上
        //drawingCircle = false;
        QPainter painter(&pixmap);
        QPen pen(penColor);
        pen.setWidth(lineThickness);
        painter.setPen(pen);
        painter.drawEllipse(currentCircle);
        //drawingCircle = true;
        update();}
    else if (event->button() == Qt::LeftButton) {
        if (drawing) {
            //drawing = false;
            linePoints.clear();
        }

        linePoints.clear();
    }
}

void Widget::updatePenSize(int size)
{
    lineThickness = size;
}

void Widget::updatePenColor()
{
    pen.setColor(penColor);
}

void Widget::on_penSizeSlider_actionTriggered(int value)
{
    lineThickness = value; // 更新畫筆粗細
    update(); // 觸發重繪
}




void Widget::on_comboBox_activated(int index)
{
    if (index == 0) {
        penColor = Qt::black;
    } else if (index == 1) {
        penColor = Qt::blue;
    } else if (index == 2) {
        penColor = Qt::red;
    }
    else if (index == 3) {
        penColor = Qt::white;
    }
    // 更新畫筆顏色
    updatePenColor();
    // 觸發重繪以更新畫布
    update();
}

void Widget::on_pushButton_clicked()
{
    pixmap.fill(Qt::white); // 清空畫布，填充白色背景
    // 重繪畫布
    update();
}





void Widget::on_choose_activated(int index)
{
    switch (index) {
    case 0: // 使用筆
        currentMode = Pen;
        // 保持当前选择的筆顏色，不做任何變化
        //penColor = Qt::black;
        drawingRectangle = false;
        drawingCircle = false;
        update();
        break;

    case 1: // 畫矩形
        currentMode = Rectangle;
        // 启用绘制矩形的模式
        drawingRectangle = true;
        drawingCircle = false;
        update();
        break;
    case 2: // 畫圓形
        currentMode = Circle;
        // 启用绘制圆形的模式
        drawingRectangle = false;
        drawingCircle = true;
        update();
        break;

    }
}

void Widget::on_save_clicked()
{
    // 获取桌面路径
    QString desktopPath = QStandardPaths::writableLocation(QStandardPaths::DesktopLocation);

    // 提示用户选择保存文件的路径和文件名
    QString filePath = QFileDialog::getSaveFileName(this, tr("保存绘图"), desktopPath, tr("PNG 图片 (*.png)"));

    if (!filePath.isEmpty()) {
        // 创建一个空的 QImage，与 pixmap 大小一致
        QImage image(pixmap.size(), QImage::Format_ARGB32);

        // 创建一个 QPainter 来绘制图像
        QPainter painter(&image);
        painter.fillRect(image.rect(), Qt::white); // 填充白色背景
        painter.drawPixmap(0, 0, pixmap); // 在图像上绘制 pixmap

        // 保存图像到文件
        if (image.save(filePath)) {
            // 文件保存成功
            qDebug() << "图像保存成功：" << filePath;
        } else {
            // 文件保存失败
            qDebug() << "图像保存失败：" << filePath;
        }
    }
}


void Widget::on_callout_clicked()
{
    QString filePath = QFileDialog::getOpenFileName(this, "选择图像", "", "图像文件 (*.png *.jpg *.bmp)");

    if (!filePath.isEmpty()) {
        // 加载所选图像到新的画布
        QPixmap newPixmap(filePath);
        if (!newPixmap.isNull()) {
            pixmap = newPixmap;
            update(); // 更新画布以显示新的图像
        }
    }
}

