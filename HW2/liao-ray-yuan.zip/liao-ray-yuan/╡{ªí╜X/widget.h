#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QMouseEvent>
#include <QSlider>
#include <QPen>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

protected:
    void paintEvent(QPaintEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;

private slots:
    void updatePenSize(int size);

    void on_penSizeSlider_actionTriggered(int action);


    void on_comboBox_activated(int index);





    void on_pushButton_clicked();





    void on_choose_activated(int index);

    void on_save_clicked();

    void on_callout_clicked();

private:
    Ui::Widget *ui;
    QPixmap pixmap;
    QPoint lastPoint;
    QPoint currentPoint;
    QList<QPoint> linePoints;
    bool drawing;
    QPixmap image;
    QSlider *penSizeSlider;
    int lineThickness;
    QColor brushColor;
    QColor penColor;
    void updatePenColor();
    QPen pen;
    QVector<QColor> lineColors;
    QRect currentRect; // 用於矩形繪製
    QRect previousRect; // 用於矩形繪製
    QPoint currentCircleCenter; // 用於圓形繪製
    int currentCircleRadius; // 用於圓形繪製
    bool drawingRectangle; // 表示是否正在繪製矩形
    bool drawingCircle; // 表示是否正在繪製圓形
    enum DrawingMode { Pen, Rectangle,Circle }; // 添加一个枚举来表示绘制模式
    DrawingMode currentMode; // 当前绘制模式
    QRectF currentCircle;
    QPoint circleStartPoint;

};


#endif // WIDGET_H
