#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMouseEvent>
#include <QWidget>
#include <QFileDialog>
#include <QString>
#include <QFile>
#include <QTextStream>
#include <QImage>
#include <QKeyEvent>
#include <QString>
#include <QMessageBox>
#include <QLabel>
#include <QSlider>
#include <QRectF>
#include <QPainter>
#include <QBrush>
#include <QCursor>
#include <QImageWriter>
#include <QUndoStack>
#include <QStack>
#include <QIcon>


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();



private:
    Ui::MainWindow *ui;
    QPixmap pixmap;
    QPoint lastPoint;
    QString filePath;
    QImage image;

    bool drawing;
    int r=1;

    QString color;
    QString style;
    int shape=0;

    QString shape_name;
    int width;
    int radius=0;
    //double opacity=1;
    QPoint point_one=QPoint();
    QPoint point_two=QPoint();
    QPoint point_eraser;
    QPoint point_test;


    int jk=0;
    QRect canvas;
    QCursor mouse;
    Qt::PenCapStyle capstyle;
    Qt::PenJoinStyle jointstyle;
    Qt::PenStyle penstyle;

protected:
    void paintEvent(QPaintEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;



private slots:



    QString pen_color();
    int pen_width();
    QString draw_shape();
    //double pen_opacity();
    void on_resetbutton_clicked();

    void on_actionsave_triggered();
    void on_actionopen_triggered();


    void on_spinBox_valueChanged(int arg1);
    void on_horizontalSlider_valueChanged(int value);
    void on_fillbutton_clicked();
    void on_penstyleBox_activated(int index);
    void on_capstyleBox_activated(int index);
    void on_jointstyleBox_activated(int index);
};
#endif // MAINWINDOW_H
