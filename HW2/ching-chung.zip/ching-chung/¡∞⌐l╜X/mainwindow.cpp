#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QRect canvas(QPoint(),QSize(1200,600));
    pixmap = QPixmap(canvas.size());
    pixmap.fill(Qt::white);
    this->setWindowTitle("QTpainter");
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::paintEvent(QPaintEvent *event)
{

    QPainter painter(this);
    painter.drawPixmap(QPoint(), pixmap);

    if(ui->capstyleBox->currentText()=="roundcap")
        capstyle=Qt::RoundCap;
    if(ui->capstyleBox->currentText()=="flatcap")
        capstyle=Qt::FlatCap;
    if(ui->capstyleBox->currentText()=="squarecap")
        capstyle=Qt::SquareCap;

    QPen pen(pen_color());
    pen.setWidth(pen_width());
    pen.setCapStyle(capstyle);
    pen.setJoinStyle(jointstyle);
    pen.setStyle(penstyle);
    //painter.setOpacity(pen_opacity());
    painter.setPen(pen);

    if(shape_name == "rectangle"){
        QRectF rect(point_one,point_two);
        painter.drawRect(rect.normalized());
    }

    if(draw_shape() == "circle"){
        painter.drawEllipse(point_one,radius,radius);
    }

    if(draw_shape()=="eraser"){
        painter.setPen(Qt::black);
        QRectF erer(QPoint(),QSize(pen_width()*2,pen_width()*2));
        erer.moveCenter(point_eraser);

        painter.drawRect(erer);
    }
    if(shape_name == "straight line")
        painter.drawLine(point_one,point_two);
    update();
}


void MainWindow::mousePressEvent(QMouseEvent *event)
{

    if (event->button() == Qt::LeftButton) {
        lastPoint = event->pos();
        point_one = event->pos();

        point_two=point_one;
        point_eraser= event->pos();

        update();
    }
}

void MainWindow::mouseMoveEvent(QMouseEvent *event)
{

    if ((event->buttons() & Qt::LeftButton)  ) {
        QPainter painter(&pixmap);

        if(draw_shape() == "line"){

            QPen pen(pen_color());
            pen.setWidth(pen_width());
            pen.setCapStyle(capstyle);
            pen.setJoinStyle(jointstyle);
            pen.setStyle(penstyle);
            //painter.setOpacity(pen_opacity());
            painter.setPen(pen);
            painter.setRenderHint(QPainter::Antialiasing,true);
            painter.drawLine(lastPoint, event->pos());
            lastPoint = event->pos();
        }


        if(draw_shape() == "eraser"){
            QRectF erer(QPoint(),QSize(pen_width()*2,pen_width()*2));
            erer.moveCenter(event->pos());

            painter.save();
            painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
            painter.eraseRect(erer);
            painter.restore();

        }

        point_two = event->pos();
        point_eraser=event->pos();
        radius=point_one.x()-point_two.x();
        point_test=event->pos();

        update();

    }
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event)
{

    if (event->button() == Qt::LeftButton) {
        QPainter painter(&pixmap);
        QPen pen(pen_color());
        pen.setWidth(pen_width());
        pen.setCapStyle(capstyle);
        pen.setJoinStyle(jointstyle);
        pen.setStyle(penstyle);
        painter.setPen(pen);
        //painter.setOpacity(pen_opacity());

        if(draw_shape() == "rectangle"){
            QRectF rect(point_one,point_two);
            painter.drawRect(rect.normalized());
        }
        if(draw_shape()=="circle"){
            painter.setRenderHint(QPainter::Antialiasing,true);
            painter.drawEllipse(point_one,radius,radius);
        }
        if(shape_name == "straight line")
            painter.drawLine(point_one,point_two);
        point_one=QPoint();
        point_two=QPoint();
        radius=0;

        update();
    }
}


int MainWindow::pen_width()
{
    ui->horizontalSlider->setMinimum(1);
    ui->horizontalSlider->setMaximum(60);
    ui->spinBox->setMinimum(1);
    ui->spinBox->setMaximum(60);
    width = ui->horizontalSlider->value();
    ui->spinBox->setValue(width);
    return width;
}

/*double MainWindow::pen_opacity()
{
    ui->horizontalSlider2->setMinimum(0);
    ui->horizontalSlider2->setMaximum(100);
    ui->spinBox2->setMinimum(0);
    ui->spinBox2->setMaximum(100);
    opacity = (ui->horizontalSlider2->value())/100;
    ui->spinBox2->setValue(opacity);
    return opacity;
}*/

QString MainWindow::draw_shape()
{
    shape_name = ui->modeBox->currentText();
    return shape_name;
}

void MainWindow::on_resetbutton_clicked()
{
    pixmap.toImage();
    pixmap.fill(QColor(Qt::white));
    update();
}

void MainWindow::on_actionsave_triggered()
{
    QString savefile= QFileDialog::getSaveFileName(this, "Save As");

    if (savefile.isEmpty())
        return;
    pixmap.save(savefile+".jpg","jpg",90);
}
void MainWindow::on_actionopen_triggered()
{
    filePath = QFileDialog::getOpenFileName(this,tr("OpenFile"),"",tr("Image (*.jpg *.png *.HEIC *.txt)" ));

    if(filePath.isEmpty())
        return;
    QImage img(filePath);
    QImage img2 = img.scaled(1200,600,Qt::KeepAspectRatio);
    pixmap=QPixmap::fromImage(img2);
}


void MainWindow::on_spinBox_valueChanged(int arg1)
{
    width = ui->spinBox->value();
    ui->horizontalSlider->setValue(width);
}
void MainWindow::on_horizontalSlider_valueChanged(int value)
{
    width = ui->horizontalSlider->value();
    ui->spinBox->setValue(width);
}


void MainWindow::on_fillbutton_clicked()
{
    pixmap.fill(pen_color());
}

QString MainWindow::pen_color()
{
    color = ui->colorBox->currentText();
    return color;
}

void MainWindow::on_penstyleBox_activated(int index)
{
    if(ui->penstyleBox->currentText()=="solid")
        penstyle=Qt::SolidLine;
    if(ui->penstyleBox->currentText()=="dot")
        penstyle=Qt::DotLine;
    if(ui->penstyleBox->currentText()=="dash")
        penstyle=Qt::DashLine;
    if(ui->penstyleBox->currentText()=="dashdot")
        penstyle=Qt::DashDotLine;
    if(ui->penstyleBox->currentText()=="dashdotdot")
        penstyle=Qt::DashDotDotLine;
}

void MainWindow::on_jointstyleBox_activated(int index)
{
    if(ui->jointstyleBox->currentText()=="beveljoin")
        jointstyle=Qt::BevelJoin;
    if(ui->jointstyleBox->currentText()=="miterjoin")
        jointstyle=Qt::MiterJoin;
    if(ui->jointstyleBox->currentText()=="roundjoin")
        jointstyle=Qt::RoundJoin;
}

void MainWindow::on_capstyleBox_activated(int index)
{
    if(ui->capstyleBox->currentText()=="roundcap")
        capstyle=Qt::RoundCap;
    if(ui->capstyleBox->currentText()=="flatcap")
        capstyle=Qt::FlatCap;
    if(ui->capstyleBox->currentText()=="squarecap")
        capstyle=Qt::SquareCap;
}


