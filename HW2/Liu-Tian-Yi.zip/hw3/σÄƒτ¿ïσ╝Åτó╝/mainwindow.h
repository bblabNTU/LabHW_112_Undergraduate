#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMouseEvent>
#include <QWidget>
#include <QFileDialog>
#include <QString>
#include <QFile>
#include <QTextStream>
#include <QImage>
#include <QKeyEvent>
#include <QString>
#include <QMessageBox>
#include <QLabel>
#include <QSlider>
#include <QRectF>
#include <QPainter>
#include <QBrush>
#include <QCursor>
#include <QImageWriter>
#include <QUndoStack>
#include <QStack>
#include <QIcon>


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();



private:
    Ui::MainWindow *ui;
    QPixmap pixmap;
    QPoint lastPoint;
    QString filePath;
    QImage image;
    bool drawing;
    int r=1;
    QString color;
    int width;
    QString style;
    int shape=0;
    QString shape_name;

    QPoint point_one=QPoint();
    QPoint point_two=QPoint();
    QPoint point_eraser;
    QPoint point_test;

    int radius=0;
    int jk=0;
    QRect canvas;
    QCursor mouse;


protected:
    void paintEvent(QPaintEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;




private slots:




    QString pen_color();
    int pen_width();
    QString draw_shape();


    void on_pushButton_clear_clicked();


    void on_pushButton_return_clicked();

    void on_actionsave_triggered();
    void on_actionimport_triggered();


};
#endif // MAINWINDOW_H
