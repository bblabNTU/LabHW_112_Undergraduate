#include "mainwindow.h"
#include "./ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QRect canvas(QPoint(),QSize(800,440));
    pixmap = QPixmap(canvas.size());
    pixmap.fill(Qt::white);

    ui->pushButton_clear->setIcon(QIcon(":/rec/clear.png"));
    ui->pushButton_clear->setIconSize(QSize(35,35));

}

MainWindow::~MainWindow()
{
    delete ui;

}

void MainWindow::paintEvent(QPaintEvent *event)
{

    QPainter painter(this);
    painter.drawPixmap(QPoint(), pixmap);

    QPen pen(pen_color());
    pen.setWidth(pen_width());
    pen.setCapStyle(Qt::RoundCap);
    painter.setPen(pen);

    if(shape_name == "rectangle"){

        QRectF rect(point_one,point_two);

        painter.drawRect(rect.normalized());

    }

    if(draw_shape() == "circle"){

        painter.drawEllipse(point_one,radius,radius);

    }

    if(draw_shape()=="eraser"){

        painter.setPen(Qt::black);
        QRectF erer(QPoint(),QSize(pen_width()*2,pen_width()*2));
        erer.moveCenter(point_eraser);

        painter.drawRect(erer);

    }

    update();
}



void MainWindow::mousePressEvent(QMouseEvent *event)
{

    if (event->button() == Qt::LeftButton) {

        lastPoint = event->pos();
        point_one = event->pos();

        point_two=point_one;
        point_eraser= event->pos();

        update();

    }

}

void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    if ((event->buttons() & Qt::LeftButton)  ) {
        QPainter painter(&pixmap);

        if(draw_shape() == "line"){

            QPen pen(pen_color());
            pen.setWidth(pen_width());
            pen.setCapStyle(Qt::RoundCap);
            painter.setPen(pen);
            painter.setRenderHint(QPainter::Antialiasing,true);          
            painter.drawLine(lastPoint, event->pos());
            lastPoint = event->pos();


            }


        if(draw_shape() == "eraser"){
            QRectF erer(QPoint(),QSize(pen_width()*2,pen_width()*2));
            erer.moveCenter(event->pos());

            painter.save();
            painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
            painter.eraseRect(erer);
            painter.restore();

        }

        point_two = event->pos();
        point_eraser=event->pos();
        radius=point_one.x()-point_two.x();
        point_test=event->pos();


        update();

    }
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event)
{

    if (event->button() == Qt::LeftButton) {


        QPainter painter(&pixmap);
        QPen pen(pen_color());
        pen.setWidth(pen_width());
        pen.setCapStyle(Qt::RoundCap);
        painter.setPen(pen);


        if(draw_shape() == "rectangle"){

            QRectF rect(point_one,point_two);
            painter.drawRect(rect.normalized());

        }

        if(draw_shape()=="circle"){

            painter.setRenderHint(QPainter::Antialiasing,true);
            painter.drawEllipse(point_one,radius,radius);

        }

        point_one=QPoint();
        point_two=QPoint();
        radius=0;

        update();
    }

}

QString MainWindow::pen_color()
{
    color = ui->comboBox_color->currentText();
    return color;

}

int MainWindow::pen_width()
{
    ui->horizontalSlider->setMinimum(1);
    ui->horizontalSlider->setMaximum(10);
    width = ui->horizontalSlider->value();
    return width;

}

QString MainWindow::draw_shape()
{
    shape_name = ui->comboBox_shape->currentText();
    return shape_name;

}

void MainWindow::on_pushButton_clear_clicked()
{

    pixmap.toImage();
    pixmap=QPixmap(QSize(800,440));
    pixmap.fill(QColor(Qt::white));
    update();

}

void MainWindow::on_pushButton_return_clicked()
{
    QPainter painter(&pixmap);
    QRect re(QPoint(),QSize(800,440));
    painter.save();
    painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
    painter.eraseRect(re);
    painter.restore();
}


void MainWindow::on_actionsave_triggered()
{
    QString savefile= QFileDialog::getSaveFileName(this, "Save As");

    if (savefile.isEmpty())
        return;

    pixmap.save(savefile+".jpg","jpg",90);

}


void MainWindow::on_actionimport_triggered()
{
    filePath = QFileDialog::getOpenFileName(this,tr("OpenFile"),"",tr("Image (*.jpg *.png *.HEIC *.txt)" ));

    if(filePath.isEmpty())
        return;

    QImage img(filePath);
    QImage img2 = img.scaled(800,440,Qt::KeepAspectRatio);
    pixmap=QPixmap::fromImage(img2);

}

