/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QComboBox *comboBox_shape;
    QComboBox *comboBox_color;
    QSlider *horizontalSlider;
    QPushButton *pushButton_clear;
    QPushButton *save;
    QPushButton *load;
    QSpinBox *spinBox;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        comboBox_shape = new QComboBox(centralwidget);
        comboBox_shape->addItem(QString());
        comboBox_shape->addItem(QString());
        comboBox_shape->addItem(QString());
        comboBox_shape->addItem(QString());
        comboBox_shape->setObjectName(QString::fromUtf8("comboBox_shape"));
        comboBox_shape->setGeometry(QRect(20, 520, 75, 31));
        QFont font;
        font.setFamilies({QString::fromUtf8("Palatino Linotype")});
        font.setPointSize(12);
        font.setBold(false);
        font.setItalic(false);
        comboBox_shape->setFont(font);
        comboBox_shape->setStyleSheet(QString::fromUtf8("font: 12pt \"Palatino Linotype\";"));
        comboBox_color = new QComboBox(centralwidget);
        comboBox_color->addItem(QString());
        comboBox_color->addItem(QString());
        comboBox_color->addItem(QString());
        comboBox_color->addItem(QString());
        comboBox_color->addItem(QString());
        comboBox_color->addItem(QString());
        comboBox_color->addItem(QString());
        comboBox_color->addItem(QString());
        comboBox_color->addItem(QString());
        comboBox_color->addItem(QString());
        comboBox_color->setObjectName(QString::fromUtf8("comboBox_color"));
        comboBox_color->setGeometry(QRect(110, 520, 75, 31));
        comboBox_color->setFont(font);
        comboBox_color->setStyleSheet(QString::fromUtf8("font: 12pt \"Palatino Linotype\";"));
        horizontalSlider = new QSlider(centralwidget);
        horizontalSlider->setObjectName(QString::fromUtf8("horizontalSlider"));
        horizontalSlider->setGeometry(QRect(190, 520, 160, 31));
        QFont font1;
        font1.setPointSize(10);
        horizontalSlider->setFont(font1);
        horizontalSlider->setMinimum(1);
        horizontalSlider->setMaximum(20);
        horizontalSlider->setOrientation(Qt::Horizontal);
        horizontalSlider->setTickPosition(QSlider::TicksAbove);
        horizontalSlider->setTickInterval(2);
        pushButton_clear = new QPushButton(centralwidget);
        pushButton_clear->setObjectName(QString::fromUtf8("pushButton_clear"));
        pushButton_clear->setGeometry(QRect(430, 520, 93, 31));
        QFont font2;
        font2.setFamilies({QString::fromUtf8("Palatino Linotype")});
        font2.setPointSize(15);
        font2.setBold(false);
        font2.setItalic(false);
        pushButton_clear->setFont(font2);
        pushButton_clear->setStyleSheet(QString::fromUtf8("font: 15pt \"Palatino Linotype\";"));
        save = new QPushButton(centralwidget);
        save->setObjectName(QString::fromUtf8("save"));
        save->setGeometry(QRect(540, 520, 93, 31));
        save->setFont(font);
        save->setStyleSheet(QString::fromUtf8("font: 12pt \"Palatino Linotype\";"));
        load = new QPushButton(centralwidget);
        load->setObjectName(QString::fromUtf8("load"));
        load->setGeometry(QRect(650, 520, 93, 31));
        load->setFont(font);
        load->setStyleSheet(QString::fromUtf8("font: 12pt \"Palatino Linotype\";"));
        spinBox = new QSpinBox(centralwidget);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));
        spinBox->setGeometry(QRect(360, 520, 44, 31));
        spinBox->setFont(font1);
        spinBox->setMinimum(1);
        spinBox->setMaximum(20);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 25));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        comboBox_shape->setItemText(0, QCoreApplication::translate("MainWindow", "line", nullptr));
        comboBox_shape->setItemText(1, QCoreApplication::translate("MainWindow", "eraser", nullptr));
        comboBox_shape->setItemText(2, QCoreApplication::translate("MainWindow", "rectangle", nullptr));
        comboBox_shape->setItemText(3, QCoreApplication::translate("MainWindow", "circle", nullptr));

        comboBox_color->setItemText(0, QCoreApplication::translate("MainWindow", "black", nullptr));
        comboBox_color->setItemText(1, QCoreApplication::translate("MainWindow", "red", nullptr));
        comboBox_color->setItemText(2, QCoreApplication::translate("MainWindow", "blue", nullptr));
        comboBox_color->setItemText(3, QCoreApplication::translate("MainWindow", "yellow", nullptr));
        comboBox_color->setItemText(4, QCoreApplication::translate("MainWindow", "green", nullptr));
        comboBox_color->setItemText(5, QCoreApplication::translate("MainWindow", "purple", nullptr));
        comboBox_color->setItemText(6, QCoreApplication::translate("MainWindow", "pink", nullptr));
        comboBox_color->setItemText(7, QCoreApplication::translate("MainWindow", "orange", nullptr));
        comboBox_color->setItemText(8, QCoreApplication::translate("MainWindow", "gray", nullptr));
        comboBox_color->setItemText(9, QCoreApplication::translate("MainWindow", "white", nullptr));

        pushButton_clear->setText(QCoreApplication::translate("MainWindow", "clear", nullptr));
        save->setText(QCoreApplication::translate("MainWindow", "save", nullptr));
        load->setText(QCoreApplication::translate("MainWindow", "load", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
