#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QStatusBar>
#include <QMouseEvent>
#include <QPainter>
#include <QApplication>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    void paintEvent(QPaintEvent *event);
    QString pencolor();
    int penwidth();
    QString mode();

private slots:

    void on_pushButton_clear_clicked();

    void on_save_clicked();

    void on_load_clicked();

private:
    Ui::MainWindow *ui;
    QLabel *statusLabel;
    QLabel *MousePosLabel;
    QPixmap pixmap;
    QString filePath,shape_name,color;
    int radius,width;
    QPoint point_one,point_two,point_test,point_eraser,lastPoint;
};
#endif // MAINWINDOW_H

