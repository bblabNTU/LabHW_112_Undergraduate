#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QApplication>
#include<QPainter>
#include <opencv2/opencv.hpp>
#include <QFileDialog>


using namespace cv;
using namespace std;

Mat image1;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle (tr("Littledrawer"));
    statusLabel = new QLabel;
    statusLabel->setText (tr("current position:"));
    statusLabel->setFixedWidth (100);
    MousePosLabel = new QLabel;
    MousePosLabel->setText (tr(""));
    MousePosLabel->setFixedWidth (100);
    statusBar () -> addPermanentWidget (statusLabel);
    statusBar () ->addPermanentWidget (MousePosLabel) ;
    this->setMouseTracking (true) ;
    QRect canvas(QPoint(),QSize(900,500));
    pixmap = QPixmap(canvas.size());
    pixmap.fill(Qt::white);
    connect(ui->spinBox,SIGNAL(valueChanged(int)),ui->horizontalSlider,SLOT(setValue(int)));
    connect(ui->horizontalSlider,SIGNAL(valueChanged(int)),ui->spinBox,SLOT(setValue(int)));
    ui->save->setStyleSheet("background-color:rgb(255,170,127)");
    ui->load->setStyleSheet("background-color:rgb(255,170,127)");
    ui->pushButton_clear->setStyleSheet("background-color:rgb(255,170,127)");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.drawPixmap(QPoint(), pixmap);
    QPixmap downcolor(900,78);
    downcolor.fill(Qt::gray);
    painter.drawPixmap(0,500,900,578,downcolor);
    QPen pen(pencolor());
    pen.setWidth(penwidth());
    pen.setCapStyle(Qt::RoundCap);
    painter.setPen(pen);

    if(mode() == "rectangle"){
        QRectF rect(point_one,point_two);
        painter.drawRect(rect.normalized());
    }

    if(mode() == "circle"){
        painter.drawEllipse(point_one,radius,radius);
    }

    if(mode()=="eraser"){
        painter.setPen(Qt::black);
        QRectF erer(QPoint(),QSize(penwidth()*2,penwidth()*2));
        erer.moveCenter(point_eraser);
        painter.drawRect(erer);
    }
    update();
}



void MainWindow::mousePressEvent(QMouseEvent *event)
{
    QString str = "(" + QString::number(event->x()) + "," + QString::number(event->y()) +")";
    if(event->button() == Qt::LeftButton){
        statusBar()-> showMessage(tr("left click")+str);
    }else if(event-> button() == Qt::RightButton){
        statusBar()-> showMessage(tr("right click")+str);
    }else if(event->button() == Qt::MiddleButton){
        statusBar()-> showMessage(tr("middle click")+str);
    }
    if (event->button() == Qt::LeftButton) {
        lastPoint = event->pos();
        point_one = event->pos();
        point_two=point_one;
        point_eraser= event->pos();
        update();
    }
}

void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    MousePosLabel->setText("(" + QString::number(event->x()) + "," + QString::number(event->y()) +")");
    if ((event->buttons() & Qt::LeftButton)  ) {
        QPainter painter(&pixmap);
        if(mode() == "line"){
            QPen pen(pencolor());
            pen.setWidth(penwidth());
            pen.setCapStyle(Qt::RoundCap);
            painter.setPen(pen);
            painter.setRenderHint(QPainter::Antialiasing,true);
            painter.drawLine(lastPoint, event->pos());
            lastPoint = event->pos();
        }
        if(mode() == "eraser"){
            QRectF erer(QPoint(),QSize(penwidth()*2,penwidth()*2));
            erer.moveCenter(event->pos());
            painter.save();
            painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
            painter.eraseRect(erer);
            painter.restore();
        }
        point_two = event->pos();
        point_eraser=event->pos();
        radius=point_one.x()-point_two.x();
        point_test=event->pos();
        update();
    }
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event)
{
    QString str = "(" + QString::number(event->x()) + "," + QString::number(event->y()) +")";
    statusBar()->showMessage(tr("release at : ") + str, 3000);
    if (event->button() == Qt::LeftButton) {
        QPainter painter(&pixmap);
        QPen pen(pencolor());
        pen.setWidth(penwidth());
        pen.setCapStyle(Qt::RoundCap);
        painter.setPen(pen);

        if(mode() == "rectangle"){
            QRectF rect(point_one,point_two);
            painter.drawRect(rect.normalized());
        }

        if(mode()=="circle"){
            painter.setRenderHint(QPainter::Antialiasing,true);
            painter.drawEllipse(point_one,radius,radius);
        }
        point_one=QPoint();
        point_two=QPoint();
        radius=0;
        update();
    }
}

QString MainWindow::pencolor()
{
    color = ui->comboBox_color->currentText();
    ui->comboBox_color->setItemData( 0, QColor( Qt::black ), Qt::BackgroundRole );
    ui->comboBox_color->setItemData( 0, QColor( Qt::white ), Qt::ForegroundRole );
    ui->comboBox_color->setItemData( 1, QColor( Qt::red ), Qt::BackgroundRole );
    ui->comboBox_color->setItemData( 1, QColor( Qt::black ), Qt::ForegroundRole );
    ui->comboBox_color->setItemData( 2, QColor( Qt::blue ), Qt::BackgroundRole );
    ui->comboBox_color->setItemData( 2, QColor( Qt::black ), Qt::ForegroundRole );
    ui->comboBox_color->setItemData( 3, QColor( Qt::yellow ), Qt::BackgroundRole );
    ui->comboBox_color->setItemData( 3, QColor( Qt::black ), Qt::ForegroundRole );
    ui->comboBox_color->setItemData( 4, QColor( Qt::green ), Qt::BackgroundRole );
    ui->comboBox_color->setItemData( 4, QColor( Qt::black ), Qt::ForegroundRole );
    QColor purple(160,32,240);
    ui->comboBox_color->setItemData( 5, QColor( purple ), Qt::BackgroundRole );
    ui->comboBox_color->setItemData( 5, QColor( Qt::black ), Qt::ForegroundRole );
    QColor pink(255,192,203);
    ui->comboBox_color->setItemData( 6, QColor( pink ), Qt::BackgroundRole );
    ui->comboBox_color->setItemData( 6, QColor( Qt::black ), Qt::ForegroundRole );
    QColor orange(255,165,0);
    ui->comboBox_color->setItemData( 7, QColor( orange ), Qt::BackgroundRole );
    ui->comboBox_color->setItemData( 7, QColor( Qt::black ), Qt::ForegroundRole );
    ui->comboBox_color->setItemData( 8, QColor( Qt::gray ), Qt::BackgroundRole );
    ui->comboBox_color->setItemData( 8, QColor( Qt::black ), Qt::ForegroundRole );
    ui->comboBox_color->setItemData( 9, QColor( Qt::white ), Qt::BackgroundRole );
    ui->comboBox_color->setItemData( 9, QColor( Qt::black ), Qt::ForegroundRole );
    if(color=="black")
    {
        ui->comboBox_color->setStyleSheet("background-color:rgb(0,0,0); color:rgb(255,255,255)");
    }else if(color=="red")
    {
        ui->comboBox_color->setStyleSheet("background-color:rgb(255,0,0); color:rgb(0,0,0)");
    }else if(color=="blue")
    {
        ui->comboBox_color->setStyleSheet("background-color:rgb(0,0,255); color:rgb(0,0,0)");
    }else if(color=="yellow")
    {
        ui->comboBox_color->setStyleSheet("background-color:rgb(255,255,0); color:rgb(0,0,0)");
    }else if(color=="green")
    {
        ui->comboBox_color->setStyleSheet("background-color:rgb(0,255,0); color:rgb(0,0,0)");
    }else if(color=="purple")
    {
        ui->comboBox_color->setStyleSheet("background-color:rgb(160,32,240); color:rgb(0,0,0)");
    }else if(color=="pink")
    {
        ui->comboBox_color->setStyleSheet("background-color:rgb(255,192,203); color:rgb(0,0,0)");
    }else if(color=="orange")
    {
        ui->comboBox_color->setStyleSheet("background-color:rgb(255,165,0); color:rgb(0,0,0)");
    }else if(color=="gray")
    {
        ui->comboBox_color->setStyleSheet("background-color:rgb(192,192,192); color:rgb(0,0,0)");
    }else if(color=="white")
    {
        ui->comboBox_color->setStyleSheet("background-color:rgb(255,255,255); color:rgb(0,0,0)");
    }
    return color;
}

int MainWindow::penwidth()
{
    ui->horizontalSlider->setMinimum(1);
    ui->horizontalSlider->setMaximum(20);
    width = ui->horizontalSlider->value();
    return width;
}

QString MainWindow::mode()
{
    shape_name = ui->comboBox_shape->currentText();
    ui->comboBox_shape->setStyleSheet("background-color:rgb(255,170,127)");
    ui->comboBox_shape->setItemData( 0, QColor( Qt::white ), Qt::BackgroundRole );
    ui->comboBox_shape->setItemData( 0, QColor( Qt::black ), Qt::ForegroundRole );
    ui->comboBox_shape->setItemData( 1, QColor( Qt::white ), Qt::BackgroundRole );
    ui->comboBox_shape->setItemData( 1, QColor( Qt::black ), Qt::ForegroundRole );
    ui->comboBox_shape->setItemData( 2, QColor( Qt::white ), Qt::BackgroundRole );
    ui->comboBox_shape->setItemData( 2, QColor( Qt::black ), Qt::ForegroundRole );
    ui->comboBox_shape->setItemData( 3, QColor( Qt::white ), Qt::BackgroundRole );
    ui->comboBox_shape->setItemData( 3, QColor( Qt::black ), Qt::ForegroundRole );
    return shape_name;
}

void MainWindow::on_pushButton_clear_clicked()
{
    pixmap.toImage();
    pixmap=QPixmap(QSize(900,500));
    pixmap.fill(QColor(Qt::white));
    update();
    ui->comboBox_shape->setCurrentIndex(0);
    ui->comboBox_color->setCurrentIndex(0);
    ui->horizontalSlider->setValue(1);
}


void MainWindow::on_save_clicked()
{
    QString savefile= QFileDialog::getSaveFileName(this, "Save As");
    if (savefile.isEmpty())
        return;
    pixmap.save(savefile+".jpg","jpg",90);
}


void MainWindow::on_load_clicked()
{
    filePath = QFileDialog::getOpenFileName(this,tr("OpenFile"),"",tr("Image (*.jpg *.png *.HEIC *.txt *.jpeg)" ));
    if(filePath.isEmpty())
        return;
    image1 = imread(filePath.toLocal8Bit().toStdString());
    cvtColor(image1, image1,COLOR_BGR2RGB );
    cv::resize(image1, image1, Size(900,500));
    QImage img = QImage((const unsigned char*)(image1.data), image1.cols, image1.rows,QImage::Format_RGB888);
    QPixmap pix;
    pix = QPixmap::fromImage(img);
    QPainter p(&pixmap);
    p.drawPixmap(0,0,pix);
    update();
    ui->comboBox_shape->setCurrentIndex(0);
    ui->comboBox_color->setCurrentIndex(0);
    ui->horizontalSlider->setValue(1);
}






