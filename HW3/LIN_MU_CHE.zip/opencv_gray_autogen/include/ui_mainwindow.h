/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *load;
    QGraphicsView *origin;
    QGraphicsView *gray;
    QGraphicsView *gaussian;
    QGraphicsView *average;
    QGraphicsView *sobel;
    QGraphicsView *laplacian;
    QLabel *Gaussian;
    QLabel *Origin;
    QLabel *Gray;
    QLabel *Sobel;
    QLabel *Laplacian;
    QLabel *Average;
    QLabel *label;
    QSpinBox *spinBox;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        load = new QPushButton(centralwidget);
        load->setObjectName(QString::fromUtf8("load"));
        load->setGeometry(QRect(350, 490, 93, 28));
        origin = new QGraphicsView(centralwidget);
        origin->setObjectName(QString::fromUtf8("origin"));
        origin->setGeometry(QRect(10, 40, 256, 192));
        gray = new QGraphicsView(centralwidget);
        gray->setObjectName(QString::fromUtf8("gray"));
        gray->setGeometry(QRect(270, 40, 256, 192));
        gaussian = new QGraphicsView(centralwidget);
        gaussian->setObjectName(QString::fromUtf8("gaussian"));
        gaussian->setGeometry(QRect(10, 270, 256, 192));
        average = new QGraphicsView(centralwidget);
        average->setObjectName(QString::fromUtf8("average"));
        average->setGeometry(QRect(530, 40, 256, 192));
        sobel = new QGraphicsView(centralwidget);
        sobel->setObjectName(QString::fromUtf8("sobel"));
        sobel->setGeometry(QRect(270, 270, 256, 192));
        laplacian = new QGraphicsView(centralwidget);
        laplacian->setObjectName(QString::fromUtf8("laplacian"));
        laplacian->setGeometry(QRect(530, 270, 256, 192));
        Gaussian = new QLabel(centralwidget);
        Gaussian->setObjectName(QString::fromUtf8("Gaussian"));
        Gaussian->setGeometry(QRect(70, 250, 131, 20));
        Origin = new QLabel(centralwidget);
        Origin->setObjectName(QString::fromUtf8("Origin"));
        Origin->setGeometry(QRect(120, 20, 63, 19));
        Gray = new QLabel(centralwidget);
        Gray->setObjectName(QString::fromUtf8("Gray"));
        Gray->setGeometry(QRect(380, 20, 63, 19));
        Sobel = new QLabel(centralwidget);
        Sobel->setObjectName(QString::fromUtf8("Sobel"));
        Sobel->setGeometry(QRect(360, 250, 81, 19));
        Laplacian = new QLabel(centralwidget);
        Laplacian->setObjectName(QString::fromUtf8("Laplacian"));
        Laplacian->setGeometry(QRect(610, 250, 101, 19));
        Average = new QLabel(centralwidget);
        Average->setObjectName(QString::fromUtf8("Average"));
        Average->setGeometry(QRect(620, 20, 91, 20));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(90, 470, 31, 19));
        spinBox = new QSpinBox(centralwidget);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));
        spinBox->setGeometry(QRect(130, 470, 44, 24));
        spinBox->setMinimum(1);
        spinBox->setMaximum(35);
        spinBox->setSingleStep(2);
        spinBox->setValue(1);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 25));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        load->setText(QCoreApplication::translate("MainWindow", "load", nullptr));
        Gaussian->setText(QCoreApplication::translate("MainWindow", "Gaussian blur filter", nullptr));
        Origin->setText(QCoreApplication::translate("MainWindow", "\345\216\237\345\234\226", nullptr));
        Gray->setText(QCoreApplication::translate("MainWindow", "\347\201\260\351\232\216", nullptr));
        Sobel->setText(QCoreApplication::translate("MainWindow", "sobel filter", nullptr));
        Laplacian->setText(QCoreApplication::translate("MainWindow", "laplacian filter", nullptr));
        Average->setText(QCoreApplication::translate("MainWindow", "\347\201\260\351\232\216(\345\271\263\345\235\207)", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", " size", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
