/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGraphicsView *origin;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QGraphicsView *mygray;
    QGraphicsView *gray;
    QGraphicsView *gaussian;
    QGraphicsView *sobel;
    QGraphicsView *laplacian;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QPushButton *pushButton;
    QSpinBox *spinBox;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        MainWindow->setToolTipDuration(-1);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        origin = new QGraphicsView(centralwidget);
        origin->setObjectName(QString::fromUtf8("origin"));
        origin->setGeometry(QRect(10, 40, 241, 191));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(110, 20, 40, 12));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(380, 10, 81, 21));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(660, 20, 40, 12));
        mygray = new QGraphicsView(centralwidget);
        mygray->setObjectName(QString::fromUtf8("mygray"));
        mygray->setGeometry(QRect(280, 40, 241, 191));
        gray = new QGraphicsView(centralwidget);
        gray->setObjectName(QString::fromUtf8("gray"));
        gray->setGeometry(QRect(550, 40, 241, 191));
        gaussian = new QGraphicsView(centralwidget);
        gaussian->setObjectName(QString::fromUtf8("gaussian"));
        gaussian->setGeometry(QRect(10, 290, 241, 191));
        sobel = new QGraphicsView(centralwidget);
        sobel->setObjectName(QString::fromUtf8("sobel"));
        sobel->setGeometry(QRect(280, 290, 241, 191));
        laplacian = new QGraphicsView(centralwidget);
        laplacian->setObjectName(QString::fromUtf8("laplacian"));
        laplacian->setGeometry(QRect(550, 290, 241, 191));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(650, 270, 101, 20));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(380, 270, 61, 16));
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(110, 270, 91, 16));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(360, 510, 80, 18));
        spinBox = new QSpinBox(centralwidget);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));
        spinBox->setGeometry(QRect(100, 500, 42, 22));
        spinBox->setMinimum(1);
        spinBox->setMaximum(51);
        spinBox->setSingleStep(2);
        spinBox->setStepType(QAbstractSpinBox::DefaultStepType);
        spinBox->setValue(1);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 17));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "\345\216\237\345\234\226", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "\345\271\263\345\235\207\347\201\260\351\232\216", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "\347\201\260\351\232\216", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "laplacian ", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "sobel", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "Gaussian", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "\350\274\211\345\205\245\345\234\226\347\211\207", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
