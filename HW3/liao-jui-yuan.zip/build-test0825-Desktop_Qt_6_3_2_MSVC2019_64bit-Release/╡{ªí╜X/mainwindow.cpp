#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <opencv2/opencv.hpp>
#include <iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <QFileDialog>

using namespace std;
using namespace cv;


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
 ui->spinBox->setSingleStep(2);

}

MainWindow::~MainWindow()
{

    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    Mat image1,imagecopy, image_origin, image1_gray, image1_average, image1_g, image1_sx, image1_l, image1_sy, image1_s;
    filePath = QFileDialog::getOpenFileName(this,tr("開啟圖片"),"",tr("圖片 (*.jpg *.png *.HEIC *.txt *.jpeg)" ));
    if(filePath.isEmpty())
    {
        return;
    }
    image1 = imread(filePath.toLocal8Bit().toStdString());
    if (image1.empty())
    {
        cout << "失敗" << endl;
        return;
    }
    cvtColor(image1, image_origin, COLOR_BGR2RGB);  //正常
    cv::resize(image_origin, image_origin, Size(256,192));
    QImage img1 = QImage((const unsigned char*)(image_origin.data), image_origin.cols, image_origin.rows,QImage::Format_RGB888);
    QGraphicsScene *scene = new QGraphicsScene;
    scene->addPixmap(QPixmap::fromImage(img1));
    ui->origin->setScene(scene);
    ui->origin->show();

    image1_average=image1.clone(); //平均灰階
    int rows = image1_average.rows;
    int cols = image1_average.cols;
    int channel = image1_average.channels();
    for(int i = 0;i<rows;i++){
        for(int j = 0;j<cols;j++){

            if(channel == 3){
                int b = image1_average.at<Vec3b>(i,j)[0];
                int g = image1_average.at<Vec3b>(i,j)[1];
                int r = image1_average.at<Vec3b>(i,j)[2];


                image1_average.at<Vec3b>(i,j)[0] =0.30*r + 0.30*g +0.30*b;
                image1_average.at<Vec3b>(i,j)[1] =0.30*r + 0.30*g +0.30*b;
                image1_average.at<Vec3b>(i,j)[2] =0.30*r + 0.30*g +0.30*b;

            }

        }
    }
    cv::resize(image1_average, image1_average, Size(256,192));
    QImage img2 = QImage((const unsigned char*)(image1_average.data), image1_average.cols, image1_average.rows,QImage::Format_RGB888);
    QGraphicsScene *scene2 = new QGraphicsScene;
    scene2->addPixmap(QPixmap::fromImage(img2));
    ui->mygray->setScene(scene2);
    ui->mygray->show();

    cvtColor(image_origin, image1_gray, COLOR_RGB2GRAY); //灰階
    cv::resize(image1_gray, image1_gray, Size(256,192));
    QImage img3 = QImage((const unsigned char*)(image1_gray.data), image1_gray.cols, image1_gray.rows,QImage::Format_Indexed8);
    QGraphicsScene *scene3 = new QGraphicsScene;
    scene3->addPixmap(QPixmap::fromImage(img3));
    ui->gray->setScene(scene3);
    ui->gray->show();

    imagechange=image_origin.clone(); //高斯
    GaussianBlur(image_origin,image1_g,Size(1,1),0,0);
    cv::resize(image1_g, image1_g, Size(256,192));
    QImage img4 = QImage((const unsigned char*)(image1_g.data), image1_g.cols, image1_g.rows,QImage::Format_RGB888);
    QGraphicsScene *scene4 = new QGraphicsScene;
    scene4->addPixmap(QPixmap::fromImage(img4));
    ui->gaussian->setScene(scene4);
    ui->gaussian->show();

    Sobel(image1_gray,image1_sx,CV_8U,1,0,3,1,0,BORDER_DEFAULT); //所博
    Sobel(image1_gray,image1_sy,CV_8U,0,1,3,1,0,BORDER_DEFAULT);
    addWeighted(image1_sx,0.5,image1_sy,0.5,0,image1_s);
    cv::resize(image1_s, image1_s, Size(256,192));
    QImage img5 = QImage((const unsigned char*)(image1_s.data), image1_s.cols, image1_s.rows,QImage::Format_Indexed8);
    QGraphicsScene *scene5 = new QGraphicsScene;
    scene5->addPixmap(QPixmap::fromImage(img5));
    ui->sobel->setScene(scene5);
    ui->sobel->show();

    imagecopy=image1_gray.clone(); //拉普拉絲
    Laplacian(imagecopy,image1_l,CV_8U,9,1,0,BORDER_DEFAULT);
    cv::resize(image1_l, image1_l, Size(256,192));
    QImage img6 = QImage((const unsigned char*)(image1_l.data), image1_l.cols, image1_l.rows,QImage::Format_Indexed8);
    QGraphicsScene *scene6 = new QGraphicsScene;
    scene6->addPixmap(QPixmap::fromImage(img6));
    ui->laplacian->setScene(scene6);
    ui->laplacian->show();
}



void MainWindow::on_spinBox_valueChanged(int arg1)
{
    GaussianBlur(imagechange,image1_g2,Size(arg1,arg1),0,0);
    cv::resize(image1_g2, image1_g2, Size(256,192));
    QImage img4 = QImage((const unsigned char*)(image1_g2.data), image1_g2.cols, image1_g2.rows,QImage::Format_RGB888);
    QGraphicsScene *scene4 = new QGraphicsScene;
    scene4->addPixmap(QPixmap::fromImage(img4));
    ui->gaussian->setScene(scene4);
    ui->gaussian->show();
}

