#include "mainwindow.h"
#include "./ui_mainwindow.h"

using namespace std;
using namespace cv;

QString filePath, filePath_2;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->horizontalSlider->setRange(1,31);


}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    //QString filePath_3 = "/Users/klose/Desktop/paint.JPG";
    Mat image,image_original, image_gray, image_average, image_gaussian, image_sobel, image_sobelx, image_sobely, image_laplacian, image_copy;
    filePath = QFileDialog::getOpenFileName(this,tr("OpenFile"),"",tr("Image (*.jpg *.png *.HEIC *.txt *.jpeg)" ));
    filePath_2 = filePath;
    if(filePath.isEmpty())
    {
        return;
    }
    image = imread(filePath.toLocal8Bit().toStdString());
    cvtColor(image, image_original, COLOR_BGR2RGB);
    cv::resize(image_original, image_original, Size(256,192));
    QImage origin = QImage((const unsigned char*)(image_original.data), image_original.cols, image_original.rows,QImage::Format_RGB888);
    QGraphicsScene *scene = new QGraphicsScene;
    scene->addPixmap(QPixmap::fromImage(origin));
    ui->graphicsView_original->setScene(scene);
    ui->graphicsView_original->show();


    cvtColor(image_original, image_gray, COLOR_RGB2GRAY);
    cv::resize(image_gray, image_gray, Size(256,192));
    QImage gray = QImage((const unsigned char*)(image_gray.data), image_gray.cols, image_gray.rows,QImage::Format_Indexed8);
    QGraphicsScene *scene0 = new QGraphicsScene;
    scene0->addPixmap(QPixmap::fromImage(gray));
    ui->graphicsView_gray->setScene(scene0);
    ui->graphicsView_gray->show();


    image_average=image.clone();
    int rows = image_average.rows;
    int cols = image_average.cols;
    int channel = image_average.channels();
    for(int i = 0;i<rows;i++){
        for(int j = 0;j<cols;j++){

            if(channel == 3){
                int b = image_average.at<Vec3b>(i,j)[0];
                int g = image_average.at<Vec3b>(i,j)[1];
                int r = image_average.at<Vec3b>(i,j)[2];


                image_average.at<Vec3b>(i,j)[0] =0.30*r + 0.59*g +0.11*b;
                image_average.at<Vec3b>(i,j)[1] =0.30*r + 0.59*g +0.11*b;
                image_average.at<Vec3b>(i,j)[2] =0.30*r + 0.59*g +0.11*b;

            }

        }
    }

    cv::resize(image_average, image_average, Size(256,192));
    QImage gray_average = QImage((const unsigned char*)(image_average.data), image_average.cols, image_average.rows,QImage::Format_RGB888);
    QGraphicsScene *scene4 = new QGraphicsScene;
    scene4->addPixmap(QPixmap::fromImage(gray_average));
    ui->graphicsView_average->setScene(scene4);
    ui->graphicsView_average->show();



    //image_change = image.clone();
    GaussianBlur(image_original,image_gaussian,Size(1,1),0,0);
    cv::resize(image_gaussian, image_gaussian, Size(256,192));
    QImage guassian = QImage((const unsigned char*)(image_gaussian.data), image_gaussian.cols, image_gaussian.rows,QImage::Format_RGB888);
    QGraphicsScene *scene1 = new QGraphicsScene;
    scene1->addPixmap(QPixmap::fromImage(guassian));
    ui->graphicsView_gaussian->setScene(scene1);
    ui->graphicsView_gaussian->show();


    Sobel(image_gray,image_sobelx,CV_8U,1,0,3,1,0,BORDER_DEFAULT);
    Sobel(image_gray,image_sobely,CV_8U,0,1,3,1,0,BORDER_DEFAULT);
    addWeighted(image_sobelx,0.5,image_sobely,0.5,0,image_sobel);
    cv::resize(image_sobel, image_sobel, Size(256,192));
    QImage sobel = QImage((const unsigned char*)(image_sobel.data), image_sobel.cols, image_sobel.rows,QImage::Format_Indexed8);
    QGraphicsScene *scene2 = new QGraphicsScene;
    scene2->addPixmap(QPixmap::fromImage(sobel));
    ui->graphicsView_sobel->setScene(scene2);
    ui->graphicsView_sobel->show();


    image_copy = image_gray.clone();
    Laplacian(image_copy,image_laplacian,CV_8U,9,1,0,BORDER_DEFAULT);
    cv::resize(image_laplacian, image_laplacian, Size(256,192));
    QImage laplacian = QImage((const unsigned char*)(image_laplacian.data), image_laplacian.cols, image_laplacian.rows,QImage::Format_Indexed8);
    QGraphicsScene *scene3 = new QGraphicsScene;
    scene3->addPixmap(QPixmap::fromImage(laplacian));
    ui->graphicsView_laplacian->setScene(scene3);
    ui->graphicsView_laplacian->show();
}


void MainWindow::on_horizontalSlider_valueChanged(int value)
{

    //QString filePath_2 = "/Users/klose/Desktop/paint.JPG";

    Mat image_change, image_gnew;
    image_change = imread(filePath_2.toLocal8Bit().toStdString());

    if(value % 2 ==1){

        kv = value;
    }

    QString k = QString::number(kv);
    ui->label_7->setText(k);

    if(value>1){
    GaussianBlur(image_change,image_gnew,Size(kv,kv),0,0);
    cv::resize(image_gnew, image_gnew, Size(256,192));
    QImage guassian_new = QImage((const unsigned char*)(image_gnew.data), image_gnew.cols, image_gnew.rows,QImage::Format_RGB888);
    QGraphicsScene *scene1 = new QGraphicsScene;
    scene1->addPixmap(QPixmap::fromImage(guassian_new));
    ui->graphicsView_gaussian->setScene(scene1);
    ui->graphicsView_gaussian->show();
    }

}



