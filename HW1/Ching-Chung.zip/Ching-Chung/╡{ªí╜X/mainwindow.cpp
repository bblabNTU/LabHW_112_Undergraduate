#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <iostream>
#include <QFile>
#include <QTextStream>

#include <QMessageBox>
#include <QTextEdit>
#include <QMainWindow>
#include <QFileDialog>
#include <QString>
#include <QTextStream>
#include <QImage>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QPixmap pix4("./black-tea-001.ico");
    ui->label_4->setStyleSheet("border-image:url(./black-tea-001.ico);");
    ui->label_4->setPixmap(pix4);

    QPixmap pix1("./spaghetti-001.ico");
    ui->label->setStyleSheet("border-image:url(./spaghetti-001.ico);");
    ui->label->setPixmap(pix1);

    QPixmap pix2("./omelette-001.ico");
    ui->label_2->setStyleSheet("border-image:url(./omelette-001.ico);");
    ui->label_2->setPixmap(pix2);

    QPixmap pix3("./fried-rice-001.ico");
    ui->label_3->setStyleSheet("border-image:url(./fried-rice-001.ico);");
    ui->label_3->setPixmap(pix3);

    QPixmap pix5("./green-tea-001.ico");
    ui->label_5->setStyleSheet("border-image:url(./green-tea-001.ico);");
    ui->label_5->setPixmap(pix5);

    QPixmap pix6("./coke-001.ico");
    ui->label_6->setStyleSheet("border-image:url(./coke-001.ico);");
    ui->label_6->setPixmap(pix6);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_caclButton_clicked()
{
    ui->textEdit->setText("");
    ui->textEdit->setFontPointSize(14);
    QString customerChoose = "You order : ";

    int totalMoney = 0, payMoney=0;
    payMoney += 200*(ui->spinBox1->value())+180*(ui->spinBox2->value())+160*(ui->spinBox3->value());
    payMoney += 60*(ui->spinBox4->value())+50*(ui->spinBox5->value())+40*(ui->spinBox6->value());
    if(ui->spinBox1->value())
        customerChoose += "青醬麵*"+QString::number(ui->spinBox1->value())+", ";
    if(ui->spinBox2->value())
        customerChoose += "蛋包飯*"+QString::number(ui->spinBox2->value())+", ";
    if(ui->spinBox3->value())
        customerChoose += "炒飯*"+QString::number(ui->spinBox3->value())+", ";
    if(ui->spinBox4->value())
        customerChoose += "蜜香紅*"+QString::number(ui->spinBox4->value())+", ";
    if(ui->spinBox5->value())
        customerChoose += "奶綠*"+QString::number(ui->spinBox5->value())+", ";
    if(ui->spinBox6->value())
        customerChoose += "coke*"+QString::number(ui->spinBox6->value())+", ";
    ui->textEdit->append(customerChoose);
    if(ui->paycomboBox->currentIndex()==0)
        ui->textEdit->append("無優惠, "+QString::number(payMoney));
    else if(ui->paycomboBox->currentIndex()==1)
        ui->textEdit->append("學生95折, "+QString::number(payMoney*0.95));
    else
        ui->textEdit->append(QString::number(payMoney));

}


void MainWindow::on_save_order_clicked()
{
    /*
    QFile file("C:\\Users\\huchingchung\\Documents\\build-qt202306262-Desktop_Qt_6_3_2_MinGW_64_bit-Debug\\savedorder.txt");
    if (!file.open(QFile::WriteOnly | QFile::Text))     //检测文件是否打开
    {
        QMessageBox::information(this, "Error Message", "Please Select a Text File!");
        return;
    }
    QTextStream out(&file);                 //分行写入文件
    out << ui->textEdit_2->toPlainText();
    */
    QFile fileWrite("./order.txt");
    QString userInput = ui -> textEdit -> toPlainText();


    if(fileWrite.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text))
    {
        QTextStream output(&fileWrite);
        output << userInput << Qt::endl;
        fileWrite.close();
    }

    QFile fileRead("./order.txt");

    if(fileRead.open(QIODevice::ReadOnly)) //Open the file, returning true if successful; otherwise false
    {
        QTextStream input(&fileRead);
        //input.setCodec("UTF-8");
        while(!input.atEnd())
        {
            QString line = input.readLine();
            ui -> textEdit_2 -> append(line.toStdString().data());
        }
        fileRead.close();
    }
    //"C:\\Users\\huchingchung\\Documents\\build-qt202306262-Desktop_Qt_6_3_2_MinGW_64_bit-Debug\\savedorder.txt"

}
