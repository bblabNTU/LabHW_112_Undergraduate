#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <iostream>
#include <QString>
#include <QTextStream>
#include <QTextEdit>
using namespace std;
int times=1;


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("Ordering System");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    ui->result->setText("");
    ui->result->setFontPointSize(14);
    QString customerChoose = "You order : ";
    int totalMoney = 0;
    double Total=0;

    if(ui->noodles->checkState())
    {
        customerChoose+="noodels";
        totalMoney += 200;
    }
    if(ui->burgers->checkState())
    {
        customerChoose+="burgers";
        totalMoney += 180;
    }
    if(ui->eggs->checkState())
    {
        customerChoose+="eggs";
        totalMoney += 160;
    }
    if(ui->coke->checkState())
    {
        customerChoose+="coke";
        totalMoney += 60;
    }
    if(ui->sprite->checkState())
    {
        customerChoose+="sprite";
        totalMoney += 50;
    }
    if(ui->tea->checkState())
    {
        customerChoose+="tea";
        totalMoney += 40;
    }

    if(ui->tenpercent->isChecked())
    {
        Total=totalMoney*9/10;
    }
    else if(ui->thirty->isChecked())
    {
        Total=totalMoney-30;
    }
    else
    {
        ui->result->append("You have to choose a payment method!");
        return;
    }

    customerChoose.replace(customerChoose.length() - 2, 1, "");
    ui->result->append(customerChoose);
    ui->result->append("Total money is " + QString::number(Total));
}




