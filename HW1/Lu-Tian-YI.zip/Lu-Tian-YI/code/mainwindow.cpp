#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QPixmap>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("Ordering System");

    QPixmap main(":/icons/main.png");
    ui->label_main->setPixmap(main.scaled(120,120,Qt::KeepAspectRatio));

    QPixmap drink(":/icons/drink.png");
    ui->label_drink->setPixmap(drink.scaled(80,80,Qt::KeepAspectRatio));

    QPixmap payment(":/icons/payment.png");
    ui->label_payment->setPixmap(payment.scaled(70,70,Qt::KeepAspectRatio));


}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_total_clicked()
{
    int s=0;
    QString p=0;
    QStringList order;


    int checkBox_tuna=35;
    int checkBox_radish=40;
    int checkBox_burger=50;
    int checkBox_hotdog=20;
    int checkBox_dumpling=30;

    int checkBox_tea=20;
    int checkBox_soymilk=20;
    int checkBox_milktea=25;
    int checkBox_juice=35;
    int checkBox_coffee=35;



    if(ui->checkBox_tuna->isChecked()){

        s+=checkBox_tuna;
        order<<"鮪魚蛋餅";

    }

    if(ui->checkBox_radish->isChecked()){

        s+=checkBox_radish;
        order<<"蘿蔔糕";

    }

    if(ui->checkBox_burger->isChecked()){

        s+=checkBox_burger;
        order<<"里肌漢堡";

    }

    if(ui->checkBox_hotdog->isChecked()){

        s+=checkBox_hotdog;
        order<<"熱狗";

    }

    if(ui->checkBox_dumpling->isChecked()){

        s+=checkBox_dumpling;
        order<<"煎餃";

    }

    if(ui->checkBox_tea->isChecked()){

        s+=checkBox_tea;
        order<<"紅茶";

    }

    if(ui->checkBox_soymilk->isChecked()){

        s+=checkBox_soymilk;
        order<<"豆漿";

    }

    if(ui->checkBox_milktea->isChecked()){

        s+=checkBox_milktea;
        order<<"奶茶";

    }

    if(ui->checkBox_juice->isChecked()){

        s+=checkBox_juice;
        order<<"柳橙汁";

    }

    if(ui->checkBox_coffee->isChecked()){

        s+=checkBox_coffee;
        order<<"咖啡";
    }

    if(ui->radioButton_cash->isChecked()){

        p=p+"paid in cash.";
    }

    if(ui->radioButton_student->isChecked()){

        s=s-5;
        p=p+"paid with student discount.";
    }

    if(ui->radioButton_device->isChecked()){

        s=s*0.6;
        p=p+"Paid with online credit.";
    }


    QString final = order.join(", ");


    QString i = QString::number(s);
    ui->label_total->setText("You ordered :"+final+"\n"+"The total is $"+i+", "+p);
}





