/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAbstractButton>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *title;
    QTextEdit *textEdit;
    QWidget *layoutWidget5;
    QHBoxLayout *horizontalLayout_4;
    QRadioButton *card;
    QRadioButton *cash;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout;
    QRadioButton *cold1;
    QRadioButton *hot1;
    QWidget *layoutWidget3;
    QHBoxLayout *horizontalLayout_2;
    QRadioButton *hot2;
    QRadioButton *cold2;
    QWidget *layoutWidget4;
    QHBoxLayout *horizontalLayout_3;
    QRadioButton *hot3;
    QRadioButton *cold3;
    QDialogButtonBox *buttonBox;
    QCheckBox *hamburger;
    QCheckBox *sandwich;
    QCheckBox *hotdog;
    QCheckBox *milk;
    QCheckBox *coffee;
    QCheckBox *latte;
    QPushButton *save;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QTextEdit *record;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(621, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        title = new QLabel(centralwidget);
        title->setObjectName(QString::fromUtf8("title"));
        title->setGeometry(QRect(220, 30, 171, 31));
        title->setMaximumSize(QSize(200, 50));
        QFont font;
        font.setPointSize(12);
        title->setFont(font);
        title->setLineWidth(-1);
        textEdit = new QTextEdit(centralwidget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(40, 420, 251, 131));
        layoutWidget5 = new QWidget(centralwidget);
        layoutWidget5->setObjectName(QString::fromUtf8("layoutWidget5"));
        layoutWidget5->setGeometry(QRect(200, 310, 261, 25));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget5);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        card = new QRadioButton(layoutWidget5);
        card->setObjectName(QString::fromUtf8("card"));

        horizontalLayout_4->addWidget(card);

        cash = new QRadioButton(layoutWidget5);
        cash->setObjectName(QString::fromUtf8("cash"));

        horizontalLayout_4->addWidget(cash);

        layoutWidget2 = new QWidget(centralwidget);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(410, 130, 141, 25));
        horizontalLayout = new QHBoxLayout(layoutWidget2);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        cold1 = new QRadioButton(layoutWidget2);
        cold1->setObjectName(QString::fromUtf8("cold1"));

        horizontalLayout->addWidget(cold1);

        hot1 = new QRadioButton(layoutWidget2);
        hot1->setObjectName(QString::fromUtf8("hot1"));

        horizontalLayout->addWidget(hot1);

        layoutWidget3 = new QWidget(centralwidget);
        layoutWidget3->setObjectName(QString::fromUtf8("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(410, 190, 141, 25));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget3);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        hot2 = new QRadioButton(layoutWidget3);
        hot2->setObjectName(QString::fromUtf8("hot2"));

        horizontalLayout_2->addWidget(hot2);

        cold2 = new QRadioButton(layoutWidget3);
        cold2->setObjectName(QString::fromUtf8("cold2"));

        horizontalLayout_2->addWidget(cold2);

        layoutWidget4 = new QWidget(centralwidget);
        layoutWidget4->setObjectName(QString::fromUtf8("layoutWidget4"));
        layoutWidget4->setGeometry(QRect(410, 250, 141, 25));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget4);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        hot3 = new QRadioButton(layoutWidget4);
        hot3->setObjectName(QString::fromUtf8("hot3"));

        horizontalLayout_3->addWidget(hot3);

        cold3 = new QRadioButton(layoutWidget4);
        cold3->setObjectName(QString::fromUtf8("cold3"));

        horizontalLayout_3->addWidget(cold3);

        buttonBox = new QDialogButtonBox(centralwidget);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(190, 380, 193, 28));
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        hamburger = new QCheckBox(centralwidget);
        hamburger->setObjectName(QString::fromUtf8("hamburger"));
        hamburger->setGeometry(QRect(80, 130, 129, 23));
        hamburger->setMinimumSize(QSize(91, 0));
        sandwich = new QCheckBox(centralwidget);
        sandwich->setObjectName(QString::fromUtf8("sandwich"));
        sandwich->setGeometry(QRect(80, 190, 117, 23));
        hotdog = new QCheckBox(centralwidget);
        hotdog->setObjectName(QString::fromUtf8("hotdog"));
        hotdog->setGeometry(QRect(80, 250, 103, 23));
        milk = new QCheckBox(centralwidget);
        milk->setObjectName(QString::fromUtf8("milk"));
        milk->setGeometry(QRect(280, 190, 81, 23));
        coffee = new QCheckBox(centralwidget);
        coffee->setObjectName(QString::fromUtf8("coffee"));
        coffee->setGeometry(QRect(280, 130, 93, 23));
        latte = new QCheckBox(centralwidget);
        latte->setObjectName(QString::fromUtf8("latte"));
        latte->setGeometry(QRect(280, 250, 95, 23));
        save = new QPushButton(centralwidget);
        save->setObjectName(QString::fromUtf8("save"));
        save->setGeometry(QRect(260, 340, 93, 28));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(110, 90, 51, 21));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(300, 90, 51, 21));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(470, 90, 51, 21));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(30, 130, 41, 31));
        QFont font1;
        font1.setPointSize(9);
        label_4->setFont(font1);
        label_4->setScaledContents(true);
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(30, 190, 41, 31));
        label_5->setFont(font1);
        label_5->setPixmap(QPixmap(QString::fromUtf8("../../../Downloads/32386sandwich_98891.ico")));
        label_5->setScaledContents(true);
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(230, 120, 41, 31));
        label_6->setFont(font1);
        label_6->setPixmap(QPixmap(QString::fromUtf8("../../../Downloads/32432hotbeverage_98916.ico")));
        label_6->setScaledContents(true);
        label_7 = new QLabel(centralwidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(230, 180, 41, 31));
        label_7->setFont(font1);
        label_7->setPixmap(QPixmap(QString::fromUtf8("../../../Downloads/milk_icon-icons.com_63210.ico")));
        label_7->setScaledContents(true);
        label_8 = new QLabel(centralwidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(240, 250, 31, 21));
        label_8->setFont(font1);
        label_8->setPixmap(QPixmap(QString::fromUtf8("../../../Downloads/coffee-latte-macchiato_icon-icons.com_61172.ico")));
        label_8->setScaledContents(true);
        label_9 = new QLabel(centralwidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(30, 250, 41, 31));
        label_9->setFont(font1);
        label_9->setPixmap(QPixmap(QString::fromUtf8("../../../Downloads/hotdog_icon-icons.com_54393.ico")));
        label_9->setScaledContents(true);
        record = new QTextEdit(centralwidget);
        record->setObjectName(QString::fromUtf8("record"));
        record->setGeometry(QRect(320, 420, 261, 131));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 621, 25));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        title->setText(QCoreApplication::translate("MainWindow", "Ordering System", nullptr));
        card->setText(QCoreApplication::translate("MainWindow", "card 5%off", nullptr));
        cash->setText(QCoreApplication::translate("MainWindow", "cash", nullptr));
        cold1->setText(QCoreApplication::translate("MainWindow", "cold", nullptr));
        hot1->setText(QCoreApplication::translate("MainWindow", "hot", nullptr));
        hot2->setText(QCoreApplication::translate("MainWindow", "hot", nullptr));
        cold2->setText(QCoreApplication::translate("MainWindow", "cold", nullptr));
        hot3->setText(QCoreApplication::translate("MainWindow", "hot", nullptr));
        cold3->setText(QCoreApplication::translate("MainWindow", "cold", nullptr));
        hamburger->setText(QCoreApplication::translate("MainWindow", "hamburger$80", nullptr));
        sandwich->setText(QCoreApplication::translate("MainWindow", "sandwich$50", nullptr));
        hotdog->setText(QCoreApplication::translate("MainWindow", "hotdog$30", nullptr));
        milk->setText(QCoreApplication::translate("MainWindow", "milk$30", nullptr));
        coffee->setText(QCoreApplication::translate("MainWindow", "coffee$60", nullptr));
        latte->setText(QCoreApplication::translate("MainWindow", "latte$65", nullptr));
        save->setText(QCoreApplication::translate("MainWindow", "Save", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "FOOD", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "DRINK", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "ICE", nullptr));
        label_4->setText(QString());
        label_5->setText(QString());
        label_6->setText(QString());
        label_7->setText(QString());
        label_8->setText(QString());
        label_9->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
