#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <iostream>
#include <QFile>
#include <QTextStream>
#include <QTextEdit>
#include <QMessageBox>


using namespace std;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("Ordering System");
    QPixmap pix1("./chicken.jpg");
    ui->label->setStyleSheet("border-image:url(./chicken.jpg);");
    ui->label->setPixmap(pix1);

    QPixmap pix2("./frice.jpg");
    ui->label_2->setStyleSheet("border-image:url(./frice.jpg);");
    ui->label_2->setPixmap(pix2);

    QPixmap pix3("./burger.jpg");
    ui->label_3->setStyleSheet("border-image:url(./burger.jpg);");
    ui->label_3->setPixmap(pix3);

    QPixmap pix4("./tea.jpg");
    ui->label_4->setStyleSheet("border-image:url(./tea.jpg);");
    ui->label_4->setPixmap(pix4);

    QPixmap pix5("./coke.jpg");
    ui->label_5->setStyleSheet("border-image:url(./coke.jpg);");
    ui->label_5->setPixmap(pix5);

    QPixmap pix6("./s.jpg");
    ui->label_6->setStyleSheet("border-image:url(./s.jpg);");
    ui->label_6->setPixmap(pix6);
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::on_pushButton_clicked()
{
    ui->textEdit->setText("");
    ui->textEdit->setFontPointSize(12);
    QString customerChoose = "You order : ", customerPayWay = "You choose ";
    int totalMoney = 0, payMoney;

    if(ui->burger->checkState())
    {
        customerChoose += "burger, ";
        totalMoney += 300;
    }
    if(ui->chicken->checkState())
    {
        customerChoose += "chicken, ";
        totalMoney += 100;
    }
    if(ui->frice->checkState())
    {
        customerChoose += "frice, ";
        totalMoney += 200;
    }
    if(ui->coke->checkState())
    {
        customerChoose += "coke, ";
        totalMoney += 50;
    }
    if(ui->tea->checkState())
    {
        customerChoose += "lemon tea, ";
        totalMoney += 40;
    }
    if(ui->sprite->checkState())
    {
        customerChoose += "sprite, ";
        totalMoney += 60;
    }
    if(ui->yes->isChecked())
    {
        double returnMoney = totalMoney-10;
        payMoney = returnMoney;

    }
    else if (ui->no->isChecked())
    {
        payMoney = totalMoney ;
    }
    else
    {
        ui->textEdit->append("You have to choose a payment method");
        return;
    }
    customerChoose.replace(customerChoose.length() - 2, 1, ""); // clear the last punctuation, ","
    ui->textEdit->append(customerChoose);
    ui->textEdit->append("Total money is " + QString::number(totalMoney));
    ui->textEdit->append( "have to pay " + QString::number(payMoney));

}


void MainWindow::on_pushButton_2_clicked()
{
QFile file("test.txt");
    if (! file.open(QIODevice::Append|QIODevice::Text))     //检测文件是否打开
    {
        QMessageBox::information(this, "Error Message", "Please Select a Text File!");
        return;
    }
    QTextStream out(&file);                 //分行写入文件
    out << ui->textEdit->toPlainText();

}

