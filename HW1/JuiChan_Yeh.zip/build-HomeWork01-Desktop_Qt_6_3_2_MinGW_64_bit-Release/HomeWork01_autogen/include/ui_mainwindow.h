/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout_3;
    QCheckBox *checkBox_gsSpaghetti;
    QCheckBox *checkBox_tunaEgg;
    QCheckBox *checkBox_baconEgg;
    QWidget *gridLayoutWidget_2;
    QGridLayout *gridLayout_5;
    QCheckBox *checkBox_cokeCola;
    QCheckBox *checkBox_spirit;
    QCheckBox *checkBox_blackTea;
    QWidget *gridLayoutWidget_3;
    QGridLayout *gridLayout_6;
    QRadioButton *radioButton_cash;
    QRadioButton *radioButton_card;
    QLabel *Title;
    QTextBrowser *reactBox;
    QPushButton *pushButton_deal;
    QPushButton *pushButton_leave;
    QPushButton *pushButton_saving;
    QLabel *maindishes;
    QLabel *drinks;
    QLabel *payment;
    QLabel *maindishes_icon;
    QLabel *drinks_icon;
    QLabel *payment_icon;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(480, 329);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayoutWidget = new QWidget(centralwidget);
        gridLayoutWidget->setObjectName(QString::fromUtf8("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(20, 100, 141, 91));
        gridLayout_3 = new QGridLayout(gridLayoutWidget);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        checkBox_gsSpaghetti = new QCheckBox(gridLayoutWidget);
        checkBox_gsSpaghetti->setObjectName(QString::fromUtf8("checkBox_gsSpaghetti"));

        gridLayout_3->addWidget(checkBox_gsSpaghetti, 1, 0, 1, 1);

        checkBox_tunaEgg = new QCheckBox(gridLayoutWidget);
        checkBox_tunaEgg->setObjectName(QString::fromUtf8("checkBox_tunaEgg"));

        gridLayout_3->addWidget(checkBox_tunaEgg, 0, 0, 1, 1);

        checkBox_baconEgg = new QCheckBox(gridLayoutWidget);
        checkBox_baconEgg->setObjectName(QString::fromUtf8("checkBox_baconEgg"));

        gridLayout_3->addWidget(checkBox_baconEgg, 2, 0, 1, 1);

        gridLayoutWidget_2 = new QWidget(centralwidget);
        gridLayoutWidget_2->setObjectName(QString::fromUtf8("gridLayoutWidget_2"));
        gridLayoutWidget_2->setGeometry(QRect(170, 100, 141, 91));
        gridLayout_5 = new QGridLayout(gridLayoutWidget_2);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        gridLayout_5->setContentsMargins(0, 0, 0, 0);
        checkBox_cokeCola = new QCheckBox(gridLayoutWidget_2);
        checkBox_cokeCola->setObjectName(QString::fromUtf8("checkBox_cokeCola"));

        gridLayout_5->addWidget(checkBox_cokeCola, 1, 0, 1, 1);

        checkBox_spirit = new QCheckBox(gridLayoutWidget_2);
        checkBox_spirit->setObjectName(QString::fromUtf8("checkBox_spirit"));

        gridLayout_5->addWidget(checkBox_spirit, 0, 0, 1, 1);

        checkBox_blackTea = new QCheckBox(gridLayoutWidget_2);
        checkBox_blackTea->setObjectName(QString::fromUtf8("checkBox_blackTea"));

        gridLayout_5->addWidget(checkBox_blackTea, 2, 0, 1, 1);

        gridLayoutWidget_3 = new QWidget(centralwidget);
        gridLayoutWidget_3->setObjectName(QString::fromUtf8("gridLayoutWidget_3"));
        gridLayoutWidget_3->setGeometry(QRect(320, 100, 141, 61));
        gridLayout_6 = new QGridLayout(gridLayoutWidget_3);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        gridLayout_6->setContentsMargins(0, 0, 0, 0);
        radioButton_cash = new QRadioButton(gridLayoutWidget_3);
        radioButton_cash->setObjectName(QString::fromUtf8("radioButton_cash"));

        gridLayout_6->addWidget(radioButton_cash, 0, 0, 1, 1);

        radioButton_card = new QRadioButton(gridLayoutWidget_3);
        radioButton_card->setObjectName(QString::fromUtf8("radioButton_card"));

        gridLayout_6->addWidget(radioButton_card, 1, 0, 1, 1);

        Title = new QLabel(centralwidget);
        Title->setObjectName(QString::fromUtf8("Title"));
        Title->setGeometry(QRect(170, 20, 141, 31));
        QFont font;
        font.setPointSize(20);
        Title->setFont(font);
        Title->setAlignment(Qt::AlignCenter);
        reactBox = new QTextBrowser(centralwidget);
        reactBox->setObjectName(QString::fromUtf8("reactBox"));
        reactBox->setGeometry(QRect(20, 230, 431, 71));
        pushButton_deal = new QPushButton(centralwidget);
        pushButton_deal->setObjectName(QString::fromUtf8("pushButton_deal"));
        pushButton_deal->setGeometry(QRect(330, 170, 121, 20));
        pushButton_leave = new QPushButton(centralwidget);
        pushButton_leave->setObjectName(QString::fromUtf8("pushButton_leave"));
        pushButton_leave->setGeometry(QRect(390, 200, 61, 20));
        pushButton_saving = new QPushButton(centralwidget);
        pushButton_saving->setObjectName(QString::fromUtf8("pushButton_saving"));
        pushButton_saving->setGeometry(QRect(330, 200, 61, 20));
        maindishes = new QLabel(centralwidget);
        maindishes->setObjectName(QString::fromUtf8("maindishes"));
        maindishes->setGeometry(QRect(60, 70, 61, 21));
        QFont font1;
        font1.setPointSize(16);
        maindishes->setFont(font1);
        maindishes->setAlignment(Qt::AlignCenter);
        drinks = new QLabel(centralwidget);
        drinks->setObjectName(QString::fromUtf8("drinks"));
        drinks->setGeometry(QRect(210, 70, 61, 21));
        drinks->setFont(font1);
        drinks->setAlignment(Qt::AlignCenter);
        payment = new QLabel(centralwidget);
        payment->setObjectName(QString::fromUtf8("payment"));
        payment->setGeometry(QRect(360, 70, 81, 21));
        payment->setFont(font1);
        payment->setAlignment(Qt::AlignCenter);
        maindishes_icon = new QLabel(centralwidget);
        maindishes_icon->setObjectName(QString::fromUtf8("maindishes_icon"));
        maindishes_icon->setGeometry(QRect(20, 60, 51, 31));
        drinks_icon = new QLabel(centralwidget);
        drinks_icon->setObjectName(QString::fromUtf8("drinks_icon"));
        drinks_icon->setGeometry(QRect(170, 60, 51, 31));
        payment_icon = new QLabel(centralwidget);
        payment_icon->setObjectName(QString::fromUtf8("payment_icon"));
        payment_icon->setGeometry(QRect(320, 60, 41, 31));
        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        checkBox_gsSpaghetti->setText(QCoreApplication::translate("MainWindow", "\351\235\222\351\206\254\347\276\251\345\244\247\345\210\251\351\272\265 $200", nullptr));
        checkBox_tunaEgg->setText(QCoreApplication::translate("MainWindow", "\351\256\252\351\255\232\350\233\213\345\240\241  $180", nullptr));
        checkBox_baconEgg->setText(QCoreApplication::translate("MainWindow", "\345\237\271\346\240\271\347\217\255\345\260\274\350\277\252\345\205\213\350\233\213 $160", nullptr));
        checkBox_cokeCola->setText(QCoreApplication::translate("MainWindow", "\345\217\257\346\250\202 $60", nullptr));
        checkBox_spirit->setText(QCoreApplication::translate("MainWindow", "\351\233\252\347\242\247 $60", nullptr));
        checkBox_blackTea->setText(QCoreApplication::translate("MainWindow", "\347\264\205\350\214\266 $40", nullptr));
        radioButton_cash->setText(QCoreApplication::translate("MainWindow", "\347\217\276\351\207\221 $30off", nullptr));
        radioButton_card->setText(QCoreApplication::translate("MainWindow", "\345\210\267\345\215\241 10%off", nullptr));
        Title->setText(QCoreApplication::translate("MainWindow", "\351\273\236\351\244\220\347\263\273\347\265\261", nullptr));
        pushButton_deal->setText(QCoreApplication::translate("MainWindow", "\350\250\210\347\256\227\345\223\201\351\240\205/\346\224\257\344\273\230\351\207\221\351\241\215", nullptr));
        pushButton_leave->setText(QCoreApplication::translate("MainWindow", "\351\233\242\351\226\213", nullptr));
        pushButton_saving->setText(QCoreApplication::translate("MainWindow", "\345\255\230\346\252\224", nullptr));
        maindishes->setText(QCoreApplication::translate("MainWindow", "\344\270\273\351\244\220", nullptr));
        drinks->setText(QCoreApplication::translate("MainWindow", "\351\243\262\346\226\231", nullptr));
        payment->setText(QCoreApplication::translate("MainWindow", "\344\273\230\346\254\276\346\226\271\345\274\217", nullptr));
        maindishes_icon->setText(QString());
        drinks_icon->setText(QString());
        payment_icon->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
