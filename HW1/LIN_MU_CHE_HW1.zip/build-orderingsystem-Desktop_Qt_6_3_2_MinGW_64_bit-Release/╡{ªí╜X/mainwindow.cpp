#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include<iostream>
#include<QFile>
#include<QTextStream>
#include<QTextEdit>
#include<QString>
#include<QMessageBox>
using namespace std;
int times=1;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("Ordering System");
    QPixmap pix("..//build-orderingsystem-Desktop_Qt_6_3_2_MinGW_64_bit-Release//Hamburger.ico");
    ui->label_4->setPixmap(pix);
    QPixmap pix1("..//build-orderingsystem-Desktop_Qt_6_3_2_MinGW_64_bit-Release//hotdog_icon-icons.com_54393.ico");
    ui->label_9->setPixmap(pix1);
    QPixmap pix2("..//build-orderingsystem-Desktop_Qt_6_3_2_MinGW_64_bit-Release//coffee-latte-macchiato_icon-icons.com_61172.ico");
    ui->label_8->setPixmap(pix2);
    QPixmap pix3("..//build-orderingsystem-Desktop_Qt_6_3_2_MinGW_64_bit-Release//milk_icon-icons.com_63210.ico");
    ui->label_7->setPixmap(pix3);
    QPixmap pix4("..//build-orderingsystem-Desktop_Qt_6_3_2_MinGW_64_bit-Release//32432hotbeverage_98916.ico");
    ui->label_6->setPixmap(pix4);
    QPixmap pix5("..//build-orderingsystem-Desktop_Qt_6_3_2_MinGW_64_bit-Release//32386sandwich_98891.ico");
    ui->label_5->setPixmap(pix5);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_buttonBox_accepted()
{
    //setting
    ui->textEdit->setText("");
    QString order = "Your order :", payment = "Pay with :";
    int Totalmoney=0,Paymoney=0;

    if(ui->hamburger->checkState())
    {
        order += " hamburger, ";
        Totalmoney += 80;
    }
    if(ui->sandwich->checkState())
    {
        order += " sandwich, ";
        Totalmoney += 50;
    }
    if(ui->hotdog->checkState())
    {
        order += " hotdog, ";
        Totalmoney += 30;
    }
    if(ui->coffee->checkState())
    {
        Totalmoney += 60;
        if(ui->hot1->isChecked())
        {
            order += " hot coffee, ";
        }
        else if(ui->cold1->isChecked())
        {
            order += " cold coffee, ";
        }
        else
        {
            ui->textEdit->append("Please choose hot or cold.");
            return;
        }
    }
    if(ui->milk->checkState())
    {
        Totalmoney += 30;
        if(ui->hot2->isChecked())
        {
            order += " hot milk, ";
        }
        else if(ui->cold2->isChecked())
        {
            order += " cold milk, ";
        }
        else
        {
            ui->textEdit->append("Please choose hot or cold.");
            return;
        }
    }
    if(ui->latte->checkState())
    {
        Totalmoney += 65;
        if(ui->hot3->isChecked())
        {
            order += " hot latte, ";
        }
        else if(ui->cold3->isChecked())
        {
            order += " cold latte, ";
        }
        else
        {
            ui->textEdit->append("Please choose hot or cold.");
            return;
        }
    }
    if(ui->card->isChecked())
    {
        Paymoney = Totalmoney*0.95;
        payment += " card";
    }
    else if(ui->cash->isChecked())
    {
        Paymoney = Totalmoney;
        payment += " cash";
    }
    else
    {
        ui->textEdit->append("Please choose one way to pay with.");
        return;
    }

    order.replace(order.length() - 2, 1,"");
    ui->textEdit->append(order);
    ui->textEdit->append("Total money is " + QString::number(Totalmoney));
    ui->textEdit->append(payment + " , so you have to pay " + QString::number(Paymoney));

}

void MainWindow::on_buttonBox_rejected()
{
    ui->hamburger->setChecked( false );
    ui->sandwich->setChecked( false );
    ui->hotdog->setChecked( false );
    ui->coffee->setChecked( false );
    ui->milk->setChecked( false );
    ui->latte->setChecked( false );
    ui->hot1->setAutoExclusive(false);
    ui->hot1->setChecked(false);
    ui->hot1->setAutoExclusive(true);
    ui->cold1->setAutoExclusive(false);
    ui->cold1->setChecked(false);
    ui->cold1->setAutoExclusive(true);
    ui->hot2->setAutoExclusive(false);
    ui->hot2->setChecked(false);
    ui->hot2->setAutoExclusive(true);
    ui->cold2->setAutoExclusive(false);
    ui->cold2->setChecked(false);
    ui->cold2->setAutoExclusive(true);
    ui->hot3->setAutoExclusive(false);
    ui->hot3->setChecked(false);
    ui->hot3->setAutoExclusive(true);
    ui->cold3->setAutoExclusive(false);
    ui->cold3->setChecked(false);
    ui->cold3->setAutoExclusive(true);
    ui->card->setAutoExclusive(false);
    ui->card->setChecked(false);
    ui->card->setAutoExclusive(true);
    ui->cash->setAutoExclusive(false);
    ui->cash->setChecked(false);
    ui->cash->setAutoExclusive(true);
    ui->textEdit->clear();
}


void MainWindow::on_save_clicked()
{
    ui->record->clear();
    QString recordtext = ui->textEdit->toPlainText();
    ui->record->append("Your orderingrecord " + QString::number(times) + " is => ");
    ui->record->append(recordtext);
    QString outputtext = ui->record->toPlainText();
    QFile recordFile("ordering record.txt");
    if (QFile::exists("ordering record.txt"))
    {
        recordFile.open(QIODevice::ReadWrite | QIODevice::Text |QIODevice::Append);
        QTextStream out(&recordFile);
        out<<outputtext <<"\n";
        out<<"\n";
        times+=1;
    }
    else
    {
        recordFile.open(QIODevice::ReadWrite | QIODevice::Text);
        QTextStream out(&recordFile);
        out<<outputtext<<"\n";
        out<<"\n";
        times+=1;

    }
}

